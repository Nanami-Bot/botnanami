const listsay = () => { 
	return `
	
	-aidilgans`
            }
exports.listsay = listsay